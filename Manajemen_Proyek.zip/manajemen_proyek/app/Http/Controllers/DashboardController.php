<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use App\Models\Absensi;
use App\Models\Kinerja;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        // 🧍 Jumlah pegawai aktif
        $totalPegawaiAktif = Pegawai::where('status_kepegawaian', 'Aktif')->count();

        // 📅 Persentase kehadiran hari ini
        $tanggalHariIni = Carbon::today()->toDateString();
        $totalPegawai = Pegawai::count();
        $jumlahHadir = Absensi::whereDate('tanggal', $tanggalHariIni)
            ->where('status', 'Hadir')
            ->count();

        $persentaseKehadiran = $totalPegawai > 0
            ? round(($jumlahHadir / $totalPegawai) * 100, 2)
            : 0;

        // 🏆 Pegawai dengan kinerja tertinggi dan terendah
        $tertinggi = Kinerja::with('pegawai')
            ->orderByDesc('nilai')
            ->first();

        $terendah = Kinerja::with('pegawai')
            ->orderBy('nilai')
            ->first();

        return view('dashboard.index', compact(
            'totalPegawaiAktif',
            'persentaseKehadiran',
            'tertinggi',
            'terendah'
        ));
    }
}
