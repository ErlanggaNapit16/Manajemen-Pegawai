<?php

namespace App\Http\Controllers;

use App\Models\Kinerja;
use App\Models\Pegawai;
use Illuminate\Http\Request;

class KinerjaController extends Controller
{
    public function index(Request $request)
    {
        $query = Kinerja::with('pegawai');

        // 🔍 Pencarian
        if ($request->filled('search')) {
            $search = $request->search;
            $query->whereHas('pegawai', function ($q) use ($search) {
                $q->where('nama', 'like', "%$search%")
                    ->orWhere('nip', 'like', "%$search%");
            })->orWhere('periode', 'like', "%$search%");
        }

        $kinerja = $query->latest()->get();
        $pegawai = Pegawai::all();

        return view('kinerja.index', compact('kinerja', 'pegawai'));
    }

    public function create()
    {
        $pegawai = Pegawai::all();
        return view('kinerja.create', compact('pegawai'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'pegawai_id' => 'required|exists:pegawais,id',
            'tanggal_mulai' => 'required|date',
            'tanggal_selesai' => 'required|date|after_or_equal:tanggal_mulai',
            'nilai' => 'required|numeric|min:0|max:100',
            'deskripsi' => 'nullable|string',
        ]);

        $periode = $request->tanggal_mulai . ' s.d. ' . $request->tanggal_selesai;

        Kinerja::create([
            'pegawai_id' => $request->pegawai_id,
            'periode' => $periode,
            'nilai' => $request->nilai,
            'deskripsi' => $request->deskripsi,
        ]);

        return redirect()->route('kinerja.index')->with('success', 'Data kinerja berhasil ditambahkan.');
    }


    public function edit(Kinerja $kinerja)
    {
        $pegawai = Pegawai::all();

        // pecah periode ke dua tanggal (kalau format sesuai)
        [$mulai, $selesai] = explode(' s.d. ', $kinerja->periode);
        return view('kinerja.edit', compact('kinerja', 'pegawai', 'mulai', 'selesai'));
    }

    public function update(Request $request, Kinerja $kinerja)
    {
        $validated = $request->validate([
            'pegawai_id' => 'required|exists:pegawais,id',
            'tanggal_mulai' => 'required|date',
            'tanggal_selesai' => 'required|date|after_or_equal:tanggal_mulai',
            'nilai' => 'required|numeric|min:0|max:100',
            'deskripsi' => 'nullable|string',
        ]);

        $validated['periode'] = $request->tanggal_mulai . ' s.d. ' . $request->tanggal_selesai;
        unset($validated['tanggal_mulai'], $validated['tanggal_selesai']);

        $kinerja->update($validated);

        return redirect()->route('kinerja.index')->with('success', 'Data kinerja berhasil diperbarui');
    }

    public function destroy(Kinerja $kinerja)
    {
        $kinerja->delete();
        return redirect()->route('kinerja.index')->with('success', 'Data kinerja berhasil dihapus');
    }
}
