<?php

namespace App\Http\Controllers;

use App\Models\Pegawai;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class PegawaiController extends Controller
{
    /**
     * Menampilkan daftar pegawai.
     */
    public function index(Request $request)
    {
        $query = Pegawai::query();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('nama', 'like', "%{$search}%")
                  ->orWhere('nip', 'like', "%{$search}%")
                  ->orWhere('jabatan', 'like', "%{$search}%")
                  ->orWhere('unit_kerja', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status_kepegawaian')) {
            $query->where('status_kepegawaian', $request->status_kepegawaian);
        }

        $pegawai = $query->orderBy('nama')->paginate(10)->appends($request->query());
        return view('pegawai.index', compact('pegawai'));
    }

    /**
     * Form tambah pegawai.
     */
    public function create()
    {
        return view('pegawai.create');
    }

    /**
     * Simpan data baru.
     */
    public function store(Request $request)
    {
        $request->validate([
            'nip' => 'required|unique:pegawais|regex:/^[0-9]+$/',
            'nama' => 'required',
            'jabatan' => 'required',
            'unit_kerja' => 'required',
            'status_kepegawaian' => 'required',
            'foto' => 'nullable|image|max:2048',
        ]);

        $data = $request->only(['nip', 'nama', 'jabatan', 'unit_kerja', 'status_kepegawaian']);

        if ($request->hasFile('foto')) {
            $data['foto'] = $request->file('foto')->store('foto_pegawai', 'public');
        }

        Pegawai::create($data);

        return redirect()->route('pegawai.index')->with('success', 'Data pegawai berhasil ditambahkan!');
    }

    /**
     * Tampilkan detail pegawai (opsional).
     */
    public function show(Pegawai $pegawai)
    {
        return view('pegawai.show', compact('pegawai'));
    }

    /**
     * Form edit pegawai.
     */
    public function edit(Pegawai $pegawai)
    {
        return view('pegawai.edit', compact('pegawai'));
    }

    /**
     * Update data pegawai.
     */
    public function update(Request $request, Pegawai $pegawai)
    {
        $request->validate([
            'nip' => 'required|regex:/^[0-9]+$/|unique:pegawais,nip,' . $pegawai->id,
            'nama' => 'required',
            'jabatan' => 'required',
            'unit_kerja' => 'required',
            'status_kepegawaian' => 'required',
            'foto' => 'nullable|image|max:2048',
        ]);

        $data = $request->only(['nip', 'nama', 'jabatan', 'unit_kerja', 'status_kepegawaian']);

        if ($request->hasFile('foto')) {
            if ($pegawai->foto) {
                Storage::disk('public')->delete($pegawai->foto);
            }
            $data['foto'] = $request->file('foto')->store('foto_pegawai', 'public');
        }

        $pegawai->update($data);

        return redirect()->route('pegawai.index')->with('success', 'Data pegawai berhasil diperbarui!');
    }

    /**
     * Hapus pegawai.
     */
    public function destroy(Pegawai $pegawai)
    {
        if ($pegawai->foto) {
            Storage::disk('public')->delete($pegawai->foto);
        }

        $pegawai->delete();

        return redirect()->route('pegawai.index')->with('success', 'Data pegawai berhasil dihapus!');
    }
}
