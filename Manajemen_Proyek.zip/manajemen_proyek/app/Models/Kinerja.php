<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class Kinerja extends Model
{
    use HasFactory;

    protected $fillable = [
        'pegawai_id',
        'periode',
        'nilai',
        'deskripsi'
    ];

    public function pegawai()
    {
        return $this->belongsTo(Pegawai::class);
    }
}
