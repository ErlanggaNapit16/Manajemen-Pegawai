@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Data Pegawai</h2>

    <div class="d-flex justify-content-between mb-3">
        <a href="{{ route('pegawai.create') }}" class="btn btn-primary">+ Tambah Pegawai</a>

        <!-- Form Pencarian & Filter -->
        <form action="{{ route('pegawai.index') }}" method="GET" class="d-flex gap-2">
            <input type="text" name="search" value="{{ request('search') }}" class="form-control" placeholder="Cari nama / NIP / jabatan">

            <!-- ubah name jadi status_kepegawaian supaya sesuai DB & controller -->
            <select name="status_kepegawaian" class="form-select">
                <option value="">Semua Status</option>
                <option value="Aktif" {{ request('status_kepegawaian') == 'Aktif' ? 'selected' : '' }}>Aktif</option>
                <option value="Cuti" {{ request('status_kepegawaian') == 'Cuti' ? 'selected' : '' }}>Cuti</option>
                <option value="Tidak Aktif" {{ request('status_kepegawaian') == 'Tidak Aktif' ? 'selected' : '' }}>Tidak Aktif</option>
            </select>

            <button type="submit" class="btn btn-dark">Cari</button>
            <a href="{{ route('pegawai.index') }}" class="btn btn-secondary">Reset</a>
        </form>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered text-center align-middle">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>NIP</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Unit Kerja</th>
                <th>Status</th>
                <th>Foto</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($pegawai as $p)
            <tr>
                <td>
                    {{ $pegawai->firstItem() ? $pegawai->firstItem() + $loop->index : $loop->iteration }}
                </td>
                <td>{{ $p->nip }}</td>
                <td>{{ $p->nama }}</td>
                <td>{{ $p->jabatan }}</td>
                <td>{{ $p->unit_kerja }}</td>
                <td>{{ $p->status_kepegawaian }}</td>
                <td>
                    @if($p->foto && file_exists(public_path('storage/' . $p->foto)))
                        <img src="{{ asset('storage/' . $p->foto) }}" alt="Foto" width="60" class="rounded">
                    @else
                        <img src="{{ asset('images/default.png') }}" width="60" class="rounded" alt="Tidak ada foto">
                    @endif
                </td>
                <td>
                    <a href="{{ route('pegawai.edit', $p->id) }}" class="btn btn-warning btn-sm">Edit</a>
                    <form action="{{ route('pegawai.destroy', $p->id) }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button onclick="return confirm('Yakin hapus data ini?')" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="8" class="text-muted">Tidak ada data pegawai</td>
            </tr>
            @endforelse
        </tbody>
    </table>

    <!-- pagination -->
    <div class="d-flex justify-content-center">
        {{ $pegawai->links() }}
    </div>
</div>
@endsection
