@extends('layouts.app')

@section('title', 'Tambah Pegawai')

@section('content')
<h2 class="mb-4">Tambah Pegawai</h2>

<div class="card p-4">
    <form action="{{ route('pegawai.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        {{-- NIP --}}
        <div class="mb-3">
            <label for="nip" class="form-label">NIP</label>
            <input type="number" name="nip" id="nip" class="form-control" value="{{ old('nip') }}" required>
            @error('nip')
                <div class="text-danger small">{{ $message }}</div>
            @enderror
        </div>

        {{-- Nama --}}
        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" name="nama" id="nama" class="form-control" value="{{ old('nama') }}" required>
            @error('nama')
                <div class="text-danger small">{{ $message }}</div>
            @enderror
        </div>

        {{-- Jabatan --}}
        <div class="mb-3">
            <label for="jabatan" class="form-label">Jabatan</label>
            <input type="text" name="jabatan" id="jabatan" class="form-control" value="{{ old('jabatan') }}" required>
            @error('jabatan')
                <div class="text-danger small">{{ $message }}</div>
            @enderror
        </div>

        {{-- Unit Kerja --}}
        <div class="mb-3">
            <label for="unit_kerja" class="form-label">Unit Kerja</label>
            <input type="text" name="unit_kerja" id="unit_kerja" class="form-control" value="{{ old('unit_kerja') }}" required>
            @error('unit_kerja')
                <div class="text-danger small">{{ $message }}</div>
            @enderror
        </div>

        {{-- Status Kepegawaian --}}
        <div class="mb-3">
            <label for="status_kepegawaian" class="form-label">Status Kepegawaian</label>
            <select name="status_kepegawaian" id="status_kepegawaian" class="form-control" required>
                <option value="">-- Pilih Status --</option>
                <option value="Aktif" {{ old('status_kepegawaian') == 'Aktif' ? 'selected' : '' }}>Aktif</option>
                <option value="Cuti" {{ old('status_kepegawaian') == 'Cuti' ? 'selected' : '' }}>Cuti</option>
                <option value="Tidak Aktif" {{ old('status_kepegawaian') == 'Tidak Aktif' ? 'selected' : '' }}>Tidak Aktif</option>
            </select>
            @error('status_kepegawaian')
                <div class="text-danger small">{{ $message }}</div>
            @enderror
        </div>

        {{-- Foto --}}
        <div class="mb-3">
            <label for="foto" class="form-label">Foto (opsional)</label>
            <input type="file" name="foto" id="foto" class="form-control">
            @error('foto')
                <div class="text-danger small">{{ $message }}</div>
            @enderror
        </div>

        {{-- Tombol Aksi --}}
        <div class="mt-4">
            <button type="submit" class="btn btn-success">Simpan</button>
            <a href="{{ route('pegawai.index') }}" class="btn btn-secondary">Kembali</a>
        </div>
    </form>
</div>
@endsection
