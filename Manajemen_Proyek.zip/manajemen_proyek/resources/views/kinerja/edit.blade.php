@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Edit Kinerja</h2>

    <div class="card p-4">
        <form action="{{ route('kinerja.update', $kinerja->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="mb-3">
                <label>Pegawai</label>
                <select name="pegawai_id" class="form-control" required>
                    @foreach($pegawai as $p)
                    <option value="{{ $p->id }}" {{ $kinerja->pegawai_id == $p->id ? 'selected' : '' }}>
                        {{ $p->nama }} ({{ $p->nip }})
                    </option>
                    @endforeach
                </select>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label>Tanggal Mulai</label>
                    <input type="date" name="tanggal_mulai" value="{{ $mulai }}" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label>Tanggal Selesai</label>
                    <input type="date" name="tanggal_selesai" value="{{ $selesai }}" class="form-control" required>
                </div>
            </div>

            <div class="mb-3">
                <label>Nilai (1 - 10)</label>
                <input type="number" name="nilai" value="{{ $kinerja->nilai }}" class="form-control" min="1" max="10" step="0.01" required>
            </div>

            <div class="mb-3">
                <label>Deskripsi</label>
                <textarea name="deskripsi" class="form-control" rows="3">{{ $kinerja->deskripsi }}</textarea>
            </div>

            <button type="submit" class="btn btn-success">Update</button>
            <a href="{{ route('kinerja.index') }}" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</div>
@endsection