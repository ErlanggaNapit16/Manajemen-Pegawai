@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Data Kinerja Pegawai</h2>

    <div class="d-flex justify-content-between mb-3">
        <a href="{{ route('kinerja.create') }}" class="btn btn-primary">+ Tambah Kinerja</a>

        <form action="{{ route('kinerja.index') }}" method="GET" class="d-flex gap-2">
            <input type="text" name="search" value="{{ request('search') }}" class="form-control" placeholder="Cari nama / periode">
            <button type="submit" class="btn btn-dark">Cari</button>
        </form>
    </div>

    <table class="table table-bordered align-middle text-center">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Pegawai</th>
                <th>Periode</th>
                <th>Nilai</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($kinerja as $i => $k)
            <tr>
                <td>{{ $i + 1 }}</td>
                <td>{{ $k->pegawai->nama }}</td>
                <td>{{ $k->periode }}</td>
                <td>{{ $k->nilai }}</td>
                <td class="text-start">
                    @php
                        $list = preg_split("/[\r\n]+/", trim($k->deskripsi));
                    @endphp
                    @if(!empty($list))
                        <ul class="mb-0">
                            @foreach($list as $item)
                                @if(!empty($item))
                                    <li>{{ $item }}</li>
                                @endif
                            @endforeach
                        </ul>
                    @else
                        <em class="text-muted">Tidak ada deskripsi</em>
                    @endif
                </td>
                <td>
                    <a href="{{ route('kinerja.edit', $k->id) }}" class="btn btn-warning btn-sm">Edit</a>
                    <form action="{{ route('kinerja.destroy', $k->id) }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button onclick="return confirm('Yakin hapus data ini?')" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="6" class="text-muted">Tidak ada data kinerja</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection
