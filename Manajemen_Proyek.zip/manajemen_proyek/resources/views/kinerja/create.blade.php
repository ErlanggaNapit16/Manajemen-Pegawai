@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Tambah Data Kinerja</h2>

    <div class="card p-4">
        <form action="{{ route('kinerja.store') }}" method="POST">
            @csrf

            <div class="mb-3">
                <label for="pegawai_id" class="form-label">Pegawai</label>
                <select name="pegawai_id" class="form-select" required>
                    <option value="">-- Pilih Pegawai --</option>
                    @foreach($pegawai as $p)
                    <option value="{{ $p->id }}">{{ $p->nama }}</option>
                    @endforeach
                </select>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="tanggal_mulai" class="form-label">Tanggal Mulai</label>
                    <input type="date" name="tanggal_mulai" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label for="tanggal_selesai" class="form-label">Tanggal Selesai</label>
                    <input type="date" name="tanggal_selesai" class="form-control" required>
                </div>
            </div>

           <div class="mb-3">
            <label>Nilai (1 - 10)</label>
            <input type="number" name="nilai" class="form-control" min="1" max="10" step="0.01" required>
        </div>


            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi Kinerja</label>
                <textarea name="deskripsi" class="form-control" rows="5" placeholder="Masukkan satu poin per baris, contoh:
- Menyelesaikan proyek tepat waktu
- Bekerjasama dengan tim dengan baik"></textarea>
            </div>

            <button type="submit" class="btn btn-success">Simpan</button>
            <a href="{{ route('kinerja.index') }}" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</div>
@endsection