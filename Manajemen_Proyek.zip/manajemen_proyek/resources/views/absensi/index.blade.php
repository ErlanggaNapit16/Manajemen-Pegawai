@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Data Absensi</h2>

    <div class="d-flex justify-content-between mb-3">
        <a href="{{ route('absensi.create') }}" class="btn btn-primary">+ Tambah Absensi</a>

        <form action="{{ route('absensi.index') }}" method="GET" class="d-flex gap-2">
            <select name="pegawai_id" class="form-select">
                <option value="">Semua Pegawai</option>
                @foreach($pegawais as $p)
                <option value="{{ $p->id }}" {{ request('pegawai_id') == $p->id ? 'selected' : '' }}>
                    {{ $p->nama }}
                </option>
                @endforeach
            </select>

            <input type="date" name="tanggal" value="{{ request('tanggal') }}" class="form-control">

            <button class="btn btn-dark" type="submit">Filter</button>
        </form>
    </div>

    <table class="table table-bordered text-center align-middle">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama Pegawai</th>
                <th>Tanggal</th>
                <th>Waktu Masuk</th>
                <th>Waktu Pulang</th>
                <th>Status</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($absensis as $i => $a)
            <tr>
                <td>{{ $i + $absensis->firstItem() }}</td>
                <td>{{ $a->pegawai->nama }}</td>
                <td>{{ $a->tanggal }}</td>
                <td>{{ $a->waktu_masuk ?? '-' }}</td>
                <td>{{ $a->waktu_pulang ?? '-' }}</td>
                <td>{{ $a->status }}</td>
                <td>{{ $a->keterangan ?? '-' }}</td>
                <td>
                    <a href="{{ route('absensi.edit', $a->id) }}" class="btn btn-warning btn-sm">Edit</a>
                    <form action="{{ route('absensi.destroy', $a->id) }}" method="POST" class="d-inline">
                        @csrf @method('DELETE')
                        <button onclick="return confirm('Yakin hapus data ini?')" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr><td colspan="8" class="text-muted">Tidak ada data absensi</td></tr>
            @endforelse
        </tbody>
    </table>

    {{ $absensis->links() }}
</div>
@endsection
