@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<div class="container">
    <h2 class="mb-4">Dashboard</h2>

    <div class="row g-3">
        <div class="col-md-4">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Pegawai Aktif</h5>
                    <h2 class="text-primary">{{ $totalPegawaiAktif }}</h2>
                    <p class="text-muted">Total pegawai dengan status aktif</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Kehadiran Hari Ini</h5>
                    <h2 class="text-success">{{ $persentaseKehadiran }}%</h2>
                    <p class="text-muted">Persentase hadir hari ini</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Tanggal</h5>
                    <h4 class="text-secondary">{{ now()->translatedFormat('d F Y') }}</h4>
                </div>
            </div>
        </div>
    </div>

    <hr class="my-4">

    <div class="row">
        {{-- Kinerja Tertinggi --}}
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">🏆 Nilai Kinerja Tertinggi</div>
                <div class="card-body">
                    @if($tertinggi)
                        <h5>{{ $tertinggi->pegawai->nama ?? '-' }}</h5>
                        <p>NIP: {{ $tertinggi->pegawai->nip ?? '-' }}</p>
                        <p>Nilai: <strong>{{ $tertinggi->nilai }}</strong></p>
                        
                        @php
                            $deskripsiList = preg_split('/[\n;]/', $tertinggi->deskripsi ?? '', -1, PREG_SPLIT_NO_EMPTY);
                        @endphp
                        
                        @if(count($deskripsiList) > 0)
                            <ul class="text-muted">
                                @foreach($deskripsiList as $item)
                                    <li>{{ trim($item) }}</li>
                                @endforeach
                            </ul>
                        @else
                            <p class="text-muted">Tidak ada deskripsi.</p>
                        @endif
                    @else
                        <p class="text-muted">Belum ada data kinerja.</p>
                    @endif
                </div>
            </div>
        </div>

        {{-- Kinerja Terendah --}}
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-danger text-white">📉 Nilai Kinerja Terendah</div>
                <div class="card-body">
                    @if($terendah)
                        <h5>{{ $terendah->pegawai->nama ?? '-' }}</h5>
                        <p>NIP: {{ $terendah->pegawai->nip ?? '-' }}</p>
                        <p>Nilai: <strong>{{ $terendah->nilai }}</strong></p>

                        @php
                            $deskripsiList = preg_split('/[\n;]/', $terendah->deskripsi ?? '', -1, PREG_SPLIT_NO_EMPTY);
                        @endphp
                        
                        @if(count($deskripsiList) > 0)
                            <ul class="text-muted">
                                @foreach($deskripsiList as $item)
                                    <li>{{ trim($item) }}</li>
                                @endforeach
                            </ul>
                        @else
                            <p class="text-muted">Tidak ada deskripsi.</p>
                        @endif
                    @else
                        <p class="text-muted">Belum ada data kinerja.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
