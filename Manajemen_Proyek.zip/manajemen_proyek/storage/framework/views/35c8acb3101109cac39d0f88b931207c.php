

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Data Pegawai</h2>

    <div class="d-flex justify-content-between mb-3">
        <a href="<?php echo e(route('pegawai.create')); ?>" class="btn btn-primary">+ Tambah Pegawai</a>

        <!-- Form Pencarian & Filter -->
        <form action="<?php echo e(route('pegawai.index')); ?>" method="GET" class="d-flex gap-2">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Cari nama / NIP / jabatan">

            <!-- ubah name jadi status_kepegawaian supaya sesuai DB & controller -->
            <select name="status_kepegawaian" class="form-select">
                <option value="">Semua Status</option>
                <option value="Aktif" <?php echo e(request('status_kepegawaian') == 'Aktif' ? 'selected' : ''); ?>>Aktif</option>
                <option value="Cuti" <?php echo e(request('status_kepegawaian') == 'Cuti' ? 'selected' : ''); ?>>Cuti</option>
                <option value="Tidak Aktif" <?php echo e(request('status_kepegawaian') == 'Tidak Aktif' ? 'selected' : ''); ?>>Tidak Aktif</option>
            </select>

            <button type="submit" class="btn btn-dark">Cari</button>
            <a href="<?php echo e(route('pegawai.index')); ?>" class="btn btn-secondary">Reset</a>
        </form>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered text-center align-middle">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>NIP</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Unit Kerja</th>
                <th>Status</th>
                <th>Foto</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php echo e($pegawai->firstItem() ? $pegawai->firstItem() + $loop->index : $loop->iteration); ?>

                </td>
                <td><?php echo e($p->nip); ?></td>
                <td><?php echo e($p->nama); ?></td>
                <td><?php echo e($p->jabatan); ?></td>
                <td><?php echo e($p->unit_kerja); ?></td>
                <td><?php echo e($p->status_kepegawaian); ?></td>
                <td>
                    <?php if($p->foto && file_exists(public_path('storage/' . $p->foto))): ?>
                        <img src="<?php echo e(asset('storage/' . $p->foto)); ?>" alt="Foto" width="60" class="rounded">
                    <?php else: ?>
                        <img src="<?php echo e(asset('images/default.png')); ?>" width="60" class="rounded" alt="Tidak ada foto">
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('pegawai.edit', $p->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('pegawai.destroy', $p->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Yakin hapus data ini?')" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8" class="text-muted">Tidak ada data pegawai</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <!-- pagination -->
    <div class="d-flex justify-content-center">
        <?php echo e($pegawai->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\napit\OneDrive\Documents\CV\Kominfo\Tugas\manajemen_proyek\resources\views/pegawai/index.blade.php ENDPATH**/ ?>