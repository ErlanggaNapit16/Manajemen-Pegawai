

<?php $__env->startSection('title', 'Edit Pegawai'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">Edit Pegawai</h2>

<div class="card p-4">
    <form action="<?php echo e(route('pegawai.update', $pegawai->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="mb-3">
            <label for="nip" class="form-label">NIP</label>
            <input type="number" name="nip" id="nip" 
                class="form-control" 
                value="<?php echo e(old('nip', $pegawai->nip)); ?>" required>
            <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" name="nama" id="nama" 
                class="form-control" 
                value="<?php echo e(old('nama', $pegawai->nama)); ?>" required>
            <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="jabatan" class="form-label">Jabatan</label>
            <input type="text" name="jabatan" id="jabatan" 
                class="form-control" 
                value="<?php echo e(old('jabatan', $pegawai->jabatan)); ?>" required>
            <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="unit_kerja" class="form-label">Unit Kerja</label>
            <input type="text" name="unit_kerja" id="unit_kerja" 
                class="form-control" 
                value="<?php echo e(old('unit_kerja', $pegawai->unit_kerja)); ?>" required>
            <?php $__errorArgs = ['unit_kerja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="status_kepegawaian" class="form-label">Status Kepegawaian</label>
            <select name="status_kepegawaian" id="status_kepegawaian" class="form-control" required>
                <option value="">-- Pilih Status --</option>
                <option value="Aktif" <?php echo e(old('status_kepegawaian', $pegawai->status_kepegawaian) == 'Aktif' ? 'selected' : ''); ?>>Aktif</option>
                <option value="Cuti" <?php echo e(old('status_kepegawaian', $pegawai->status_kepegawaian) == 'Cuti' ? 'selected' : ''); ?>>Cuti</option>
                <option value="Tidak Aktif" <?php echo e(old('status_kepegawaian', $pegawai->status_kepegawaian) == 'Tidak Aktif' ? 'selected' : ''); ?>>Tidak Aktif</option>
            </select>
            <?php $__errorArgs = ['status_kepegawaian'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-3">
            <label for="foto" class="form-label">Foto (opsional)</label>
            <input type="file" name="foto" id="foto" class="form-control">

            <?php if($pegawai->foto): ?>
                <div class="mt-2">
                    <img src="<?php echo e(asset('storage/' . $pegawai->foto)); ?>" 
                         alt="Foto Pegawai" 
                         width="120" class="rounded shadow-sm border">
                </div>
            <?php endif; ?>

            <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger small"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mt-4">
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="<?php echo e(route('pegawai.index')); ?>" class="btn btn-secondary">Kembali</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\napit\OneDrive\Documents\CV\Kominfo\Tugas\manajemen_proyek\resources\views/pegawai/edit.blade.php ENDPATH**/ ?>