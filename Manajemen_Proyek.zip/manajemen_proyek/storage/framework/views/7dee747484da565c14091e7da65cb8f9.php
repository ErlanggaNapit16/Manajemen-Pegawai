

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Edit Absensi</h2>

    <div class="card p-4">
        <form action="<?php echo e(route('absensi.update', $absensi->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label>Pegawai</label>
                <select name="pegawai_id" class="form-select" required>
                    <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" <?php echo e($absensi->pegawai_id == $p->id ? 'selected' : ''); ?>>
                        <?php echo e($p->nama); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Tanggal</label>
                <input type="date" name="tanggal" value="<?php echo e($absensi->tanggal); ?>" class="form-control" required>
            </div>

            <div class="mb-3">
                <label>Waktu Masuk</label>
                <input type="time" name="waktu_masuk" value="<?php echo e($absensi->waktu_masuk); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label>Waktu Pulang</label>
                <input type="time" name="waktu_pulang" value="<?php echo e($absensi->waktu_pulang); ?>" class="form-control">
            </div>

            <div class="mb-3">
                <label>Status</label>
                <select name="status" class="form-select">
                    <?php $__currentLoopData = ['Hadir','Izin','Sakit','Alpha','Cuti']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s); ?>" <?php echo e($absensi->status == $s ? 'selected' : ''); ?>><?php echo e($s); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Keterangan</label>
                <textarea name="keterangan" class="form-control" rows="2"><?php echo e($absensi->keterangan); ?></textarea>
            </div>

            <button type="submit" class="btn btn-success">Update</button>
            <a href="<?php echo e(route('absensi.index')); ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\napit\OneDrive\Documents\CV\Kominfo\Tugas\manajemen_proyek\resources\views/absensi/edit.blade.php ENDPATH**/ ?>