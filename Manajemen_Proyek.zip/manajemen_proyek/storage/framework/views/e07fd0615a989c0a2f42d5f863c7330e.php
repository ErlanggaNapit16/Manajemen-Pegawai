

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Data Absensi</h2>

    <div class="d-flex justify-content-between mb-3">
        <a href="<?php echo e(route('absensi.create')); ?>" class="btn btn-primary">+ Tambah Absensi</a>

        <form action="<?php echo e(route('absensi.index')); ?>" method="GET" class="d-flex gap-2">
            <select name="pegawai_id" class="form-select">
                <option value="">Semua Pegawai</option>
                <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($p->id); ?>" <?php echo e(request('pegawai_id') == $p->id ? 'selected' : ''); ?>>
                    <?php echo e($p->nama); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <input type="date" name="tanggal" value="<?php echo e(request('tanggal')); ?>" class="form-control">

            <button class="btn btn-dark" type="submit">Filter</button>
        </form>
    </div>

    <table class="table table-bordered text-center align-middle">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Nama Pegawai</th>
                <th>Tanggal</th>
                <th>Waktu Masuk</th>
                <th>Waktu Pulang</th>
                <th>Status</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $absensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($i + $absensis->firstItem()); ?></td>
                <td><?php echo e($a->pegawai->nama); ?></td>
                <td><?php echo e($a->tanggal); ?></td>
                <td><?php echo e($a->waktu_masuk ?? '-'); ?></td>
                <td><?php echo e($a->waktu_pulang ?? '-'); ?></td>
                <td><?php echo e($a->status); ?></td>
                <td><?php echo e($a->keterangan ?? '-'); ?></td>
                <td>
                    <a href="<?php echo e(route('absensi.edit', $a->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('absensi.destroy', $a->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Yakin hapus data ini?')" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="8" class="text-muted">Tidak ada data absensi</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php echo e($absensis->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\napit\OneDrive\Documents\CV\Kominfo\Tugas\manajemen_proyek\resources\views/absensi/index.blade.php ENDPATH**/ ?>