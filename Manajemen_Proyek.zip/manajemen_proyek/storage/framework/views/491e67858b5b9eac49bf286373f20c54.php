

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Dashboard</h2>

    <div class="row g-3">
        <div class="col-md-4">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Pegawai Aktif</h5>
                    <h2 class="text-primary"><?php echo e($totalPegawaiAktif); ?></h2>
                    <p class="text-muted">Total pegawai dengan status aktif</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Kehadiran Hari Ini</h5>
                    <h2 class="text-success"><?php echo e($persentaseKehadiran); ?>%</h2>
                    <p class="text-muted">Persentase hadir hari ini</p>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card text-center shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Tanggal</h5>
                    <h4 class="text-secondary"><?php echo e(now()->translatedFormat('d F Y')); ?></h4>
                </div>
            </div>
        </div>
    </div>

    <hr class="my-4">

    <div class="row">
        
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">🏆 Nilai Kinerja Tertinggi</div>
                <div class="card-body">
                    <?php if($tertinggi): ?>
                        <h5><?php echo e($tertinggi->pegawai->nama ?? '-'); ?></h5>
                        <p>NIP: <?php echo e($tertinggi->pegawai->nip ?? '-'); ?></p>
                        <p>Nilai: <strong><?php echo e($tertinggi->nilai); ?></strong></p>
                        
                        <?php
                            $deskripsiList = preg_split('/[\n;]/', $tertinggi->deskripsi ?? '', -1, PREG_SPLIT_NO_EMPTY);
                        ?>
                        
                        <?php if(count($deskripsiList) > 0): ?>
                            <ul class="text-muted">
                                <?php $__currentLoopData = $deskripsiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e(trim($item)); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-muted">Tidak ada deskripsi.</p>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="text-muted">Belum ada data kinerja.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-md-6">
            <div class="card shadow-sm">
                <div class="card-header bg-danger text-white">📉 Nilai Kinerja Terendah</div>
                <div class="card-body">
                    <?php if($terendah): ?>
                        <h5><?php echo e($terendah->pegawai->nama ?? '-'); ?></h5>
                        <p>NIP: <?php echo e($terendah->pegawai->nip ?? '-'); ?></p>
                        <p>Nilai: <strong><?php echo e($terendah->nilai); ?></strong></p>

                        <?php
                            $deskripsiList = preg_split('/[\n;]/', $terendah->deskripsi ?? '', -1, PREG_SPLIT_NO_EMPTY);
                        ?>
                        
                        <?php if(count($deskripsiList) > 0): ?>
                            <ul class="text-muted">
                                <?php $__currentLoopData = $deskripsiList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e(trim($item)); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-muted">Tidak ada deskripsi.</p>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="text-muted">Belum ada data kinerja.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\napit\OneDrive\Documents\CV\Kominfo\Tugas\manajemen_proyek\resources\views/dashboard/index.blade.php ENDPATH**/ ?>