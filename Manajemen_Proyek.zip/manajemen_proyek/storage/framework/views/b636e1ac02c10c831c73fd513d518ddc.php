

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Tambah Data Kinerja</h2>

    <div class="card p-4">
        <form action="<?php echo e(route('kinerja.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="pegawai_id" class="form-label">Pegawai</label>
                <select name="pegawai_id" class="form-select" required>
                    <option value="">-- Pilih Pegawai --</option>
                    <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>"><?php echo e($p->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="row mb-3">
                <div class="col-md-6">
                    <label for="tanggal_mulai" class="form-label">Tanggal Mulai</label>
                    <input type="date" name="tanggal_mulai" class="form-control" required>
                </div>
                <div class="col-md-6">
                    <label for="tanggal_selesai" class="form-label">Tanggal Selesai</label>
                    <input type="date" name="tanggal_selesai" class="form-control" required>
                </div>
            </div>

           <div class="mb-3">
            <label>Nilai (1 - 10)</label>
            <input type="number" name="nilai" class="form-control" min="1" max="10" step="0.01" required>
        </div>


            <div class="mb-3">
                <label for="deskripsi" class="form-label">Deskripsi Kinerja</label>
                <textarea name="deskripsi" class="form-control" rows="5" placeholder="Masukkan satu poin per baris, contoh:
- Menyelesaikan proyek tepat waktu
- Bekerjasama dengan tim dengan baik"></textarea>
            </div>

            <button type="submit" class="btn btn-success">Simpan</button>
            <a href="<?php echo e(route('kinerja.index')); ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\napit\OneDrive\Documents\CV\Kominfo\Tugas\manajemen_proyek\resources\views/kinerja/create.blade.php ENDPATH**/ ?>