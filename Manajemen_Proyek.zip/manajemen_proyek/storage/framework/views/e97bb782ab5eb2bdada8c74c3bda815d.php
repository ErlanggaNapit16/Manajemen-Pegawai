

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2 class="mb-4">Data Kinerja Pegawai</h2>

    <div class="d-flex justify-content-between mb-3">
        <a href="<?php echo e(route('kinerja.create')); ?>" class="btn btn-primary">+ Tambah Kinerja</a>

        <form action="<?php echo e(route('kinerja.index')); ?>" method="GET" class="d-flex gap-2">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>" class="form-control" placeholder="Cari nama / periode">
            <button type="submit" class="btn btn-dark">Cari</button>
        </form>
    </div>

    <table class="table table-bordered align-middle text-center">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Pegawai</th>
                <th>Periode</th>
                <th>Nilai</th>
                <th>Deskripsi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $kinerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($i + 1); ?></td>
                <td><?php echo e($k->pegawai->nama); ?></td>
                <td><?php echo e($k->periode); ?></td>
                <td><?php echo e($k->nilai); ?></td>
                <td class="text-start">
                    <?php
                        $list = preg_split("/[\r\n]+/", trim($k->deskripsi));
                    ?>
                    <?php if(!empty($list)): ?>
                        <ul class="mb-0">
                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(!empty($item)): ?>
                                    <li><?php echo e($item); ?></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php else: ?>
                        <em class="text-muted">Tidak ada deskripsi</em>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('kinerja.edit', $k->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('kinerja.destroy', $k->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button onclick="return confirm('Yakin hapus data ini?')" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-muted">Tidak ada data kinerja</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\napit\OneDrive\Documents\CV\Kominfo\Tugas\manajemen_proyek\resources\views/kinerja/index.blade.php ENDPATH**/ ?>